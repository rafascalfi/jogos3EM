// Catálogo de Projetos Integradores - 3º EM (SESI / SENAI)
const GAMES_DATA = [
  {
    id: "agrolock",
    title: "AgroLock",
    category: "seguranca",
    categoryLabel: "Segurança & LOTO (NR-12 / NR-10)",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./AgroLock.yyz",
    size: "70.2 MB",
    thumbnail: "assets/agrolock_preview.png",
    banner: "assets/agrolock_cenario.png",
    tags: ["LOTO", "NR-12", "Agroindústria", "Colheitadeira", "Escape Room", "Bloqueio Elétrico"],
    shortDesc: "Escape Room e simulador de segurança industrial e agrícola. Aplique os procedimentos de Lockout/Tagout (LOTO) em maquinário pesado antes da manutenção preventiva.",
    fullDesc: "AgroLock é um jogo educativo de alta fidelidade técnica voltado à segurança do trabalho em ambientes agroindustriais. O jogador assume o papel de um técnico de manutenção encarregado de intervir em colheitadeiras, silos e galpões agrícolas. Antes de efetuar qualquer reparo mecânico, o jogador deve seguir rigorosamente os protocolos da NR-10 e NR-12: desenergizar o circuito, descarregar pressões residuais, aplicar o cadeado de bloqueio e fixar a etiqueta de identificação LOTO no painel principal.",
    objectives: [
      "Compreender a aplicação prática do procedimento LOTO (Lockout/Tagout).",
      "Identificar pontos críticos de aprisionamento de energia em maquinário agroindustrial.",
      "Completar as 10 fases distribuídas entre galpões, silos e linhas de colheita.",
      "Evitar acidentes de trabalho graves e agir em conformidade com as normas regulamentadoras."
    ],
    controls: [
      { key: "WASD / Setas", action: "Mover o técnico pelo cenário" },
      { key: "E / Espaço", action: "Interagir com painéis, chaves e disjuntores" },
      { key: "1 - 4", action: "Selecionar ferramentas (Cadeado LOTO, Etiqueta, Chave de Fenda, Multímetro)" },
      { key: "Tab", action: "Abrir prancheta de procedimentos e checklist de segurança" },
      { key: "Esc", action: "Pausar e menu de configurações" }
    ],
    howToRun: "Abra o GameMaker Studio (LTS 2026). Vá em 'Open' ou 'Import', selecione o arquivo 'AgroLock.yyz' e clique no botão Play (Run) para compilar e jogar nativamente."
  },
  {
    id: "factory_on_island",
    title: "Factory on the Island",
    category: "automacao",
    categoryLabel: "Automação & Gestão Industrial",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Pacote .zip / Pasta",
    downloadPath: "./FactoryOnTheIsland.zip",
    size: "48.5 MB",
    thumbnail: "assets/factory_map.png",
    banner: "assets/factory_map.png",
    tags: ["Gestão", "Sobrevivência", "Geradores", "Manutenção", "Indústria 4.0", "Pixel Art"],
    shortDesc: "Assuma o controle de uma fábrica isolada em uma ilha. Restaure sistemas, repare a ponte para a refinaria, equilibre energia com geradores e placas solares para consertar o navio de fuga.",
    fullDesc: "Desenvolvido em GameMaker LTS 2026 com base no Game Design Document (GDD 2.1). O jogador controla um especialista que desembarca em uma ilha industrial abandonada. O mapa integra costa litorânea, refinaria petrolífera, mina e oficina. O objetivo consiste em restaurar os geradores, manter as máquinas lubrificadas e prevenidas contra falhas críticas, balancear a rede elétrica de 20 UE e acumular os recursos necessários para reconstruir o navio cargueiro e escapar.",
    objectives: [
      "Gerenciar ciclos de produção com matérias-primas e sucatas.",
      "Realizar manutenção preventiva e corretiva com chave, alicate e peças de reposição.",
      "Administrar o consumo elétrico entre geradores a biomassa, diesel e energia solar.",
      "Concluir todas as etapas da campanha nos modos Fácil, Médio ou Difícil."
    ],
    controls: [
      { key: "WASD / Setas", action: "Mover o personagem (frames 16x16)" },
      { key: "Shift", action: "Correr" },
      { key: "E / Clique Esquerdo", action: "Interagir com o alvo próximo / Abrir máquina" },
      { key: "1 a 5 / Roda", action: "Equipar ferramentas: Chave, Alicate, Machado, Picareta, Galão" },
      { key: "Tab / M", action: "Inventário / Mapa da ilha" },
      { key: "R / Espaço (em máquina)", action: "Restaurar / Ligar ou desligar equipamento" },
      { key: "P (em máquina)", action: "Realizar manutenção preventiva com chave e sucata" },
      { key: "F5 / F9", action: "Salvar manualmente / Carregar save" },
      { key: "F11", action: "Alternar tela cheia / modo janela" }
    ],
    howToRun: "Extraia o arquivo 'FactoryOnTheIsland.zip'. Abra o arquivo 'FactoryOnTheIsland.yyp' no GameMaker LTS 2026 e pressione Run (F5). Você também pode compilar o executável para Windows com o script Build.ps1 incluso."
  },
  {
    id: "wood_energy_tycoon",
    title: "Wood Energy Tycoon",
    category: "tycoon",
    categoryLabel: "Tycoon & Eficiência Energética",
    engine: "Unity",
    engineBadge: "Unity 3D Standalone",
    fileType: "Executável Windows (.zip)",
    downloadPath: "./WoodEnergyTycoon-Windows.zip",
    size: "95.4 MB",
    thumbnail: "assets/wood_energy_preview.svg",
    banner: "assets/wood_energy_preview.svg",
    tags: ["Unity 3D", "Biomassa", "Energia Limpa", "Simulação", "Tycoon", "Sustentabilidade"],
    shortDesc: "Simulador 3D completo de gestão de usina de biomassa e silvicultura sustentável. Desenvolvido em Unity com física e renderização DirectX 12 para Windows.",
    fullDesc: "Wood Energy Tycoon coloca o jogador na liderança de um complexo de geração termelétrica a partir de biomassa florestal sustentável. Desenvolvido para Windows x64 em Unity, o projeto explora o ciclo de corte e replantio de eucalipto e pinus, alimentação de caldeiras de alta pressão, cogeração de vapor e venda de energia para a rede nacional (SIN). O jogador deve otimizar lucros, reduzir emissões de particulados e evitar apagões por falta de insumos.",
    objectives: [
      "Planejar áreas de corte e reflorestamento para garantir fornecimento contínuo de madeira.",
      "Controlar a queima eficiente nas caldeiras e turbinas geradoras.",
      "Modernizar filtros ambientais e sistemas de captação de fuligem.",
      "Cumprir metas contratuais de fornecimento de megawatts-hora (MWh)."
    ],
    controls: [
      { key: "WASD / Mouse", action: "Navegar pela câmera 3D da usina e do bosque" },
      { key: "Scroll do Mouse", action: "Zoom in / Zoom out" },
      { key: "Botão Esquerdo", action: "Selecionar caldeira, talhão de árvores ou transportador" },
      { key: "Botão Direito", action: "Rotacionar visão do complexo" },
      { key: "Barra de Espaço", action: "Pausar ou acelerar a velocidade da simulação" }
    ],
    howToRun: "Baixe o arquivo compactado 'WoodEnergyTycoon-Windows.zip', extraia em qualquer pasta do seu computador e dê duplo clique em 'WoodEnergyTycoon.exe' para jogar diretamente no Windows (não requer Unity instalado)."
  },
  {
    id: "safelift",
    title: "SafeLift",
    category: "seguranca",
    categoryLabel: "Logística Segura & Operação de Empilhadeira",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./SafeLift.yyz",
    size: "58.8 MB",
    thumbnail: "assets/safelift_preview.png",
    banner: "assets/safelift_preview.png",
    tags: ["Empilhadeira", "Logística", "NR-11", "Prevenção de Queda", "Galpão", "Física 2D"],
    shortDesc: "Simulação de operação segura de empilhadeiras em centro logístico. Transporte paletes e cargas industriais respeitando velocidade, raio de giro e zonas de pedestres.",
    fullDesc: "SafeLift trabalha os preceitos da Norma Regulamentadora NR-11 (Transporte, Movimentação, Armazenagem e Manuseio de Materiais). O jogador pilota uma empilhadeira industrial em corredores estreitos de galpões logísticos. Curvas em excesso de velocidade, transporte de carga em altura proibida ou invasão de faixas de pedestres causam desestabilização da carga, pontuação negativa ou encerramento imediato por acidente operacional.",
    objectives: [
      "Aprender a postura correta e manuseio seguro dos garfos da empilhadeira.",
      "Desviar de obstáculos dinâmicos e funcionários pedestres sinalizados.",
      "Empilhar cargas em estantes porta-paletes de diferentes níveis.",
      "Concluir o circuito logístico com zero infrações de segurança."
    ],
    controls: [
      { key: "W / S (ou Setas Cima/Baixo)", action: "Acelerar e dar ré na empilhadeira" },
      { key: "A / D (ou Setas Esq/Dir)", action: "Esterçar rodas traseiras (direção realista)" },
      { key: "Q / E", action: "Subir e descer torre de elevação dos garfos" },
      { key: "Espaço", action: "Acionar freio de estacionamento" },
      { key: "B", action: "Acionar buzina obrigatória em cruzamentos" }
    ],
    howToRun: "Importe o pacote 'SafeLift.yyz' no GameMaker Studio e clique em Executar (Play) para testar os desafios do centro de distribuição."
  },
  {
    id: "omega",
    title: "OMEGA: Assembly & Automation",
    category: "automacao",
    categoryLabel: "Automação & Esteiras (Factorio-style)",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./OMEGA.yyz",
    size: "83.1 MB",
    thumbnail: "assets/omega_assembler.png",
    banner: "assets/omega_assembler.png",
    tags: ["Automação", "Linha de Montagem", "Sensores", "Braço Robótico", "Puzzles", "Factorio"],
    shortDesc: "Construa, sincronize e otimize uma linha de montagem com esteiras industriais, sensores fotoelétricos, braços robóticos e montadoras automatizadas.",
    fullDesc: "Inspirado em títulos consagrados de engenharia como Factorio e Mindustry, OMEGA desafia os alunos a projetarem circuitos de fluxo contínuo de materiais. Peças brutas entram pelas esteiras e devem passar por prensas, furadeiras, estações de soldagem e inspeção óptica. O jogador precisa programar a temporização das cancelas e a filtragem de componentes para evitar estrangulamentos ('bottlenecks') na fábrica.",
    objectives: [
      "Roteamento de esteiras com curvas, divisores e junções balanceadas.",
      "Instalação de sensores e braços mecânicos para descarte de peças fora do padrão.",
      "Otimização da taxa de peças entregues por minuto (PPM).",
      "Resolução de quebra-cabeças lógicos industriais progressivos."
    ],
    controls: [
      { key: "Mouse", action: "Arrastar e posicionar esteiras, braços e maquinário" },
      { key: "R", action: "Girar orientação do componente antes da fixação" },
      { key: "Del / Botão Direito", action: "Remover esteira ou máquina incorreta" },
      { key: "Espaço", action: "Iniciar fluxo contínuo de materiais" },
      { key: "Scroll", action: "Zoom in/out na planta fabril" }
    ],
    howToRun: "Abra 'OMEGA.yyz' no GameMaker Studio LTS. Execute o projeto para desenhar e rodar sua fábrica automatizada."
  },
  {
    id: "torno_cnc",
    title: "Simulador Torno CNC",
    category: "usinagem",
    categoryLabel: "Usinagem CNC & Usinagem Mecânica",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./torno.yyz",
    size: "31.7 KB",
    thumbnail: "assets/torno_preview.svg",
    banner: "assets/torno_preview.svg",
    tags: ["CNC", "Torno Mecânico", "G-Code", "Usinagem", "Metalmecânica", "Setup de Máquina"],
    shortDesc: "Simulador técnico de operação de Torno Mecânico e CNC. Calcule rotação (RPM), profundidade de corte, avanço e realize o torneamento de precisão de eixos de aço.",
    fullDesc: "Desenvolvido em GML com modelo cinemático e interface gráfica dedicada (`scr_cnc_model.gml` e `scr_cnc_ui.gml`). O simulador reproduz as condições reais de uma oficina de usinagem industrial: fixação de peças cilíndricas na placa de 3 castanhas, zeramento de ferramentas nos eixos X e Z, cálculo da velocidade de corte (Vc) e execução de desbaste, acabamento e sangramento com pastilhas de metal duro.",
    objectives: [
      "Calcular a rotação ideal da placa em função do diâmetro da peça e do material.",
      "Realizar o zeramento de coordenadas (Work Offset / G54).",
      "Executar torneamento cilíndrico externo sem gerar quebra de ferramenta.",
      "Verificar tolerâncias dimensionais com paquímetro e micrômetro virtuais."
    ],
    controls: [
      { key: "Setas / Teclado Numérico", action: "Deslocamento dos eixos X (diâmetro) e Z (comprimento)" },
      { key: "R / T", action: "Ajustar RPM da árvore (rotações por minuto)" },
      { key: "F", action: "Ajustar velocidade de avanço da ferramenta de corte" },
      { key: "C", action: "Ligar / desligar bomba de óleo solúvel (refrigeração)" },
      { key: "Espaço", action: "Parada de emergência do torno" }
    ],
    howToRun: "Importe 'torno.yyz' no GameMaker Studio e execute para acessar o console de operação do torno mecânico e CNC."
  },
  {
    id: "virtual_restoration",
    title: "Virtual Restoration",
    category: "manutencao",
    categoryLabel: "Gêmeo Digital & Manutenção Preditiva",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./Virtual Restoration.yyz",
    size: "16.2 MB",
    thumbnail: "assets/virtual_restoration_fornalha.png",
    banner: "assets/virtual_restoration_fornalha.png",
    tags: ["Gêmeo Digital", "Termografia", "Fornalha", "Manutenção Preditiva", "Sensores", "Vibração"],
    shortDesc: "Gêmeo digital e diagnóstico em tempo real de fornalhas e caldeiras industriais. Analise termografia, vibração e substitua componentes antes da falha catastrófica.",
    fullDesc: "Virtual Restoration reproduz os conceitos mais modernos da Indústria 4.0: o gêmeo digital (Digital Twin). O jogador monitora fornalhas e motores industriais por meio de telemetria computadorizada. Detectando picos de vibração ou temperatura anômala em tempo hábil, o técnico deve planejar uma parada preventiva programada, isolar a fornalha e executar a restauração de refratários e rolamentos.",
    objectives: [
      "Interpretar gráficos de telemetria térmica e acústica de maquinário pesado.",
      "Classificar falhas em preventiva, preditiva ou corretiva emergencial.",
      "Reparar fornos industriais sem interromper a produção global da planta.",
      "Minimizar o custo de homem-hora e peças de reposição."
    ],
    controls: [
      { key: "WASD", action: "Navegar pela sala de controle e pelo chão de fábrica" },
      { key: "Clique do Mouse", action: "Selecionar sensores no painel de telemetria" },
      { key: "T", action: "Alternar visão de câmera termográfica infravermelha" },
      { key: "R", action: "Iniciar procedimento de restauração e troca de peças" }
    ],
    howToRun: "Abra 'Virtual Restoration.yyz' no GameMaker Studio e execute para iniciar a simulação de telemetria e restauração industrial."
  },
  {
    id: "game2",
    title: "GAME 2: Técnico Multidisciplinar",
    category: "manutencao",
    categoryLabel: "Treinamento Técnico Multidisciplinar",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./GAME2.yyz",
    size: "7.3 MB",
    thumbnail: "assets/game2_bg_menu.png",
    banner: "assets/game2_bg_menu.png",
    tags: ["Eletrotécnica", "Mecânica", "Construção Civil", "Metalurgia", "Quiz", "Oficina"],
    shortDesc: "Treinamento rápido de competências técnicas integradas: elétrica residencial e industrial, mecânica de manutenção, conformação de metais e obras civis.",
    fullDesc: "GAME2 foi estruturado em módulos temáticos com cenários personalizados para cada especialidade técnica: spr_bg_electrical, spr_bg_mechanics, spr_bg_metalworking e spr_bg_construction. O aluno é submetido a situações-problema reais do cotidiano de uma fábrica e canteiro de obras, testando raciocínio rápido, seleção correta de ferramentas (alicate amperímetro, torquímetro, nível bolha) e procedimentos padronizados.",
    objectives: [
      "Praticar conceitos fundamentais de comandos elétricos e ligações trifásicas.",
      "Identificar ferramentas corretas para cada classe de manutenção mecânica.",
      "Resolver desafios de usinagem e serralheria industrial.",
      "Fixar conhecimentos interdisciplinares do currículo do Ensino Médio Técnico."
    ],
    controls: [
      { key: "Mouse", action: "Selecionar respostas, ferramentas e circuitos nos painéis" },
      { key: "1 a 4", action: "Escolha rápida de itens e ferramentas de diagnóstico" },
      { key: "Enter", action: "Confirmar montagem ou resposta" }
    ],
    howToRun: "Importe 'GAME2.yyz' no GameMaker Studio LTS e execute para rodar as estações de treinamento prático."
  },
  {
    id: "tycoon2d",
    title: "Tycoon 2D: Eficiência Fabril",
    category: "tycoon",
    categoryLabel: "Gestão Energética & Chão de Fábrica 2D",
    engine: "GameMaker",
    engineBadge: "GameMaker LTS",
    fileType: "Projeto .yyz",
    downloadPath: "./tycoon2d.yyz",
    size: "21.1 MB",
    thumbnail: "assets/tycoon2d_bg.png",
    banner: "assets/tycoon2d_bg.png",
    tags: ["Tycoon 2D", "Gestão Energética", "Chão de Fábrica", "Coolers", "Geradores", "Economia"],
    shortDesc: "Simulador 2D em visão lateral de eficiência energética. Gerencie geradores, coolers de resfriamento, esteiras de produção e evite sobrecargas na rede elétrica.",
    fullDesc: "Focado no desafio 3 dos temas de GameMaker (Tycoon de Eficiência Energética em visão lateral 2D). O jogador acompanha os andares de um complexo fabril e deve manter a linha de montagem em funcionamento constante. Se as máquinas aquecerem demais, o jogador precisa acionar coolers adicionais; se o consumo de megawatts exceder a capacidade dos geradores, a fábrica sofre apagão total, gerando prejuízos imediatos.",
    objectives: [
      "Equilibrar geração térmica/solar com a demanda dos motores das máquinas.",
      "Controlar a dissipação de calor nos maquinários com módulos de refrigeração.",
      "Cumprir as metas de produção de cada turno de trabalho.",
      "Investir capital em melhorias tecnológicas mais eficientes e sustentáveis."
    ],
    controls: [
      { key: "Mouse / Clique", action: "Construir, melhorar e ligar/desligar geradores e coolers" },
      { key: "Espaço", action: "Pausar turno de produção para análise de indicadores" },
      { key: "1 - 3", action: "Acelerar velocidade do turno da fábrica" }
    ],
    howToRun: "Importe 'tycoon2d.yyz' no GameMaker Studio e execute para iniciar a administração do parque fabril."
  }
];
