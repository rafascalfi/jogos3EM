// Mini-Jogos Interativos Web (Jogue Diretamente no Navegador)
class ArcadeSimulator {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext("2d");
    this.currentMode = "conveyor"; // "conveyor" ou "loto"
    
    this.canvas.width = 760;
    this.canvas.height = 360;
    
    // Conveyor Game State
    this.conveyorState = {
      running: false,
      score: 0,
      lives: 3,
      speed: 2.2,
      gateOpen: false, // false: reto (armazém), true: desvia (reciclagem)
      items: [],
      spawnTimer: 0,
      combo: 0
    };
    
    // LOTO Game State
    this.lotoState = {
      running: false,
      step: 0, // 0: Start, 1: Emergency Stop, 2: Breaker, 3: Multimeter, 4: Lock, 5: Tag, 6: Success!
      voltage: 380,
      timeLeft: 30,
      timerInterval: null,
      message: "Clique em Iniciar para começar o procedimento LOTO!"
    };
    
    this.lastTime = 0;
    this.initEvents();
    this.startConveyor();
    this.loop = this.loop.bind(this);
    requestAnimationFrame(this.loop);
  }
  
  initEvents() {
    this.canvas.addEventListener("click", (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const x = (e.clientX - rect.left) * (this.canvas.width / rect.width);
      const y = (e.clientY - rect.top) * (this.canvas.height / rect.height);
      
      if (this.currentMode === "conveyor") {
        this.handleConveyorClick(x, y);
      } else {
        this.handleLotoClick(x, y);
      }
    });
  }
  
  switchMode(mode) {
    this.currentMode = mode;
    if (mode === "conveyor") {
      this.startConveyor();
    } else {
      this.startLoto();
    }
  }
  
  // ================= CONVEYOR GAME =================
  startConveyor() {
    this.conveyorState = {
      running: true,
      score: 0,
      lives: 3,
      speed: 2.5,
      gateOpen: false,
      items: [],
      spawnTimer: 0,
      combo: 0
    };
  }
  
  toggleGate() {
    this.conveyorState.gateOpen = !this.conveyorState.gateOpen;
  }
  
  handleConveyorClick(x, y) {
    // Se clicou na área da cancela (x entre 380 e 460)
    if (!this.conveyorState.running && this.conveyorState.lives <= 0) {
      this.startConveyor();
      return;
    }
    this.toggleGate();
  }
  
  updateConveyor(dt) {
    if (!this.conveyorState.running) return;
    
    // Spawn
    this.conveyorState.spawnTimer += dt;
    if (this.conveyorState.spawnTimer > 1200 / this.conveyorState.speed) {
      this.conveyorState.spawnTimer = 0;
      const isDefective = Math.random() < 0.45;
      this.conveyorState.items.push({
        x: 0,
        y: 180,
        defective: isDefective,
        type: isDefective ? "DEFEITO" : (Math.random() < 0.5 ? "ENGRENAGEM" : "CHIP"),
        color: isDefective ? "#ef4444" : (Math.random() < 0.5 ? "#06b6d4" : "#10b981")
      });
    }
    
    // Update items
    const gateX = 400;
    for (let i = this.conveyorState.items.length - 1; i >= 0; i--) {
      const item = this.conveyorState.items[i];
      item.x += this.conveyorState.speed * (dt / 16);
      
      // Chegou na cancela
      if (item.x >= gateX && !item.diverted) {
        if (this.conveyorState.gateOpen) {
          item.diverted = true;
        }
      }
      
      if (item.diverted) {
        item.y += this.conveyorState.speed * (dt / 16);
      }
      
      // Destino: Descarte / Reciclagem (y > 330)
      if (item.y > 330) {
        if (item.defective) {
          this.conveyorState.score += 100;
          this.conveyorState.combo++;
        } else {
          this.conveyorState.lives--;
          this.conveyorState.combo = 0;
        }
        this.conveyorState.items.splice(i, 1);
        continue;
      }
      
      // Destino: Armazém final (x > 740)
      if (item.x > 740) {
        if (!item.defective) {
          this.conveyorState.score += 150;
          this.conveyorState.combo++;
        } else {
          this.conveyorState.lives--;
          this.conveyorState.combo = 0;
        }
        this.conveyorState.items.splice(i, 1);
        continue;
      }
    }
    
    // Game Over
    if (this.conveyorState.lives <= 0) {
      this.conveyorState.running = false;
    }
    
    // Speed up gradually
    this.conveyorState.speed = Math.min(6.5, 2.5 + (this.conveyorState.score / 1500));
  }
  
  renderConveyor() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Fundo fábrica
    ctx.fillStyle = "#090d16";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Grade de chão industrial
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let x = 0; x < this.canvas.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < this.canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.canvas.width, y);
      ctx.stroke();
    }
    
    // Esteira Principal (Horizontal)
    ctx.fillStyle = "#1e293b";
    ctx.fillRect(0, 160, this.canvas.width, 50);
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 3;
    ctx.strokeRect(0, 160, this.canvas.width, 50);
    
    // Rolos da esteira
    ctx.fillStyle = "#334155";
    for (let rx = 20; rx < this.canvas.width; rx += 50) {
      ctx.fillRect(rx, 165, 6, 40);
    }
    
    // Esteira Secundária de Desvio (Vertical para baixo)
    ctx.fillStyle = "#1e293b";
    ctx.fillRect(380, 205, 50, 155);
    ctx.strokeRect(380, 205, 50, 155);
    for (let ry = 220; ry < 360; ry += 30) {
      ctx.fillRect(385, ry, 40, 6);
    }
    
    // Placas de destino
    // Armazém (Direita)
    ctx.fillStyle = "rgba(16, 185, 129, 0.2)";
    ctx.fillRect(660, 140, 100, 90);
    ctx.strokeStyle = "#10b981";
    ctx.strokeRect(660, 140, 100, 90);
    ctx.fillStyle = "#10b981";
    ctx.font = "bold 12px Inter, sans-serif";
    ctx.fillText("ARMAZÉM", 680, 160);
    ctx.fillText("(PEÇAS BOAS)", 670, 175);
    
    // Reciclagem (Baixo)
    ctx.fillStyle = "rgba(239, 68, 68, 0.2)";
    ctx.fillRect(350, 310, 110, 50);
    ctx.strokeStyle = "#ef4444";
    ctx.strokeRect(350, 310, 110, 50);
    ctx.fillStyle = "#ef4444";
    ctx.fillText("RECICLAGEM", 365, 330);
    ctx.fillText("(DEFEITUOSAS)", 360, 345);
    
    // Cancela / Desviador Robótico
    const gateX = 405;
    const gateY = 160;
    ctx.save();
    ctx.translate(gateX, gateY);
    if (this.conveyorState.gateOpen) {
      // Aberta: angulada 45 graus para desviar
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = "#f59e0b";
    } else {
      // Fechada: alinhada ao topo
      ctx.fillStyle = "#64748b";
    }
    ctx.fillRect(0, 0, 12, 60);
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, 12, 60);
    ctx.restore();
    
    // Indicador da cancela
    ctx.fillStyle = this.conveyorState.gateOpen ? "#f59e0b" : "#38bdf8";
    ctx.font = "bold 13px Inter, sans-serif";
    ctx.fillText(this.conveyorState.gateOpen ? "CANCELA: DESVIO [ATIVO]" : "CANCELA: DIRETO [RETO]", 330, 135);
    
    // Render Itens
    this.conveyorState.items.forEach(item => {
      ctx.save();
      ctx.shadowColor = item.color;
      ctx.shadowBlur = 10;
      ctx.fillStyle = item.color;
      ctx.beginPath();
      ctx.arc(item.x, item.y, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 10px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(item.defective ? "X" : "OK", item.x, item.y + 4);
    });
    
    // HUD Superior
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
    ctx.fillRect(15, 12, 730, 45);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    ctx.strokeRect(15, 12, 730, 45);
    
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 16px Inter, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`PONTOS: ${this.conveyorState.score}`, 30, 40);
    
    // Vidas
    ctx.fillStyle = "#ef4444";
    let hearts = "❤ ".repeat(Math.max(0, this.conveyorState.lives));
    ctx.fillText(`VIDAS: ${hearts}`, 220, 40);
    
    // Instrução
    ctx.fillStyle = "#38bdf8";
    ctx.font = "13px Inter, sans-serif";
    ctx.fillText("CLIQUE NA TELA PARA ALTERNAR A CANCELA (DESVIAR PEÇAS COM X)", 390, 40);
    
    // Game Over Overlay
    if (!this.conveyorState.running) {
      ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      
      ctx.fillStyle = "#f8fafc";
      ctx.font = "bold 32px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("FIM DE TURNO NA FÁBRICA!", this.canvas.width / 2, 150);
      
      ctx.fillStyle = "#38bdf8";
      ctx.font = "20px Inter, sans-serif";
      ctx.fillText(`Pontuação Final: ${this.conveyorState.score}`, this.canvas.width / 2, 190);
      
      ctx.fillStyle = "#10b981";
      ctx.font = "bold 16px Inter, sans-serif";
      ctx.fillText("Clique aqui para Jogar Novamente", this.canvas.width / 2, 235);
    }
  }
  
  // ================= LOTO GAME =================
  startLoto() {
    this.lotoState = {
      running: true,
      step: 1, // Step 1: E-Stop
      voltage: 380,
      timeLeft: 25,
      message: "Passo 1/5: Pressione o botão de PARADA DE EMERGÊNCIA (Cogumelo Vermelho)!"
    };
    
    if (this.lotoState.timerInterval) clearInterval(this.lotoState.timerInterval);
    this.lotoState.timerInterval = setInterval(() => {
      if (this.lotoState.running && this.lotoState.step < 6) {
        this.lotoState.timeLeft--;
        if (this.lotoState.timeLeft <= 0) {
          this.lotoState.running = false;
          this.lotoState.message = "TEMPO ESGOTADO! O procedimento violou a norma de segurança.";
        }
      }
    }, 1000);
  }
  
  handleLotoClick(x, y) {
    if (!this.lotoState.running && this.lotoState.step !== 6) {
      this.startLoto();
      return;
    }
    
    // Step 1: Botão Cogumelo de Emergência (x: 100, y: 150, r: 40)
    if (this.lotoState.step === 1) {
      const dist = Math.hypot(x - 120, y - 180);
      if (dist < 45) {
        this.lotoState.step = 2;
        this.lotoState.message = "Passo 2/5: Excelente! Agora DESARME A CHAVE GERAL no painel elétrico.";
      }
    }
    // Step 2: Chave Geral / Disjuntor (x: 230, y: 140, w: 60, h: 80)
    else if (this.lotoState.step === 2) {
      if (x >= 220 && x <= 290 && y >= 130 && y <= 230) {
        this.lotoState.step = 3;
        this.lotoState.voltage = 0;
        this.lotoState.message = "Passo 3/5: Tensão desarmada! Use o MULTÍMETRO para confirmar Tensão Zero (0V).";
      }
    }
    // Step 3: Multímetro de Teste (x: 350, y: 140, w: 80, h: 80)
    else if (this.lotoState.step === 3) {
      if (x >= 340 && x <= 430 && y >= 130 && y <= 230) {
        this.lotoState.step = 4;
        this.lotoState.message = "Passo 4/5: Testado com sucesso (0 Volts)! Agora APLIQUE A GARRA E O CADEADO LOTO.";
      }
    }
    // Step 4: Cadeado LOTO (x: 480, y: 140, w: 80, h: 80)
    else if (this.lotoState.step === 4) {
      if (x >= 470 && x <= 560 && y >= 130 && y <= 230) {
        this.lotoState.step = 5;
        this.lotoState.message = "Passo 5/5: Cadeado fixado! Agora PREENCHA E COLOQUE A ETIQUETA DE IDENTIFICAÇÃO.";
      }
    }
    // Step 5: Etiqueta LOTO (x: 610, y: 140, w: 80, h: 80)
    else if (this.lotoState.step === 5) {
      if (x >= 600 && x <= 690 && y >= 130 && y <= 230) {
        this.lotoState.step = 6;
        this.lotoState.message = "PARABÉNS! Procedimento NR-10/NR-12 LOTO concluído com total segurança!";
      }
    } else if (this.lotoState.step === 6) {
      this.startLoto();
    }
  }
  
  renderLoto() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Fundo Painel Elétrico Industrial
    ctx.fillStyle = "#111827";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Moldura do Painel
    ctx.strokeStyle = "#374151";
    ctx.lineWidth = 4;
    ctx.strokeRect(20, 20, 720, 320);
    
    // Barra superior
    ctx.fillStyle = "#1f2937";
    ctx.fillRect(22, 22, 716, 50);
    ctx.fillStyle = "#f8fafc";
    ctx.font = "bold 16px Inter, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("SIMULADOR DE PROCEDIMENTO DE BLOQUEIO LOTO (NR-10 / NR-12)", 35, 52);
    
    ctx.fillStyle = this.lotoState.timeLeft > 10 ? "#10b981" : "#ef4444";
    ctx.font = "bold 16px Inter, sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(`TEMPO: ${this.lotoState.timeLeft}s`, 710, 52);
    
    // Estações de Passos (5 Caixas)
    const steps = [
      { id: 1, name: "1. E-STOP", x: 80, y: 120, w: 90, h: 120, active: this.lotoState.step >= 1 },
      { id: 2, name: "2. DISJUNTOR", x: 210, y: 120, w: 90, h: 120, active: this.lotoState.step >= 2 },
      { id: 3, name: "3. MULTÍMETRO", x: 340, y: 120, w: 90, h: 120, active: this.lotoState.step >= 3 },
      { id: 4, name: "4. CADEADO", x: 470, y: 120, w: 90, h: 120, active: this.lotoState.step >= 4 },
      { id: 5, name: "5. ETIQUETA", x: 600, y: 120, w: 90, h: 120, active: this.lotoState.step >= 5 }
    ];
    
    steps.forEach(s => {
      const isCurrent = this.lotoState.step === s.id;
      const isDone = this.lotoState.step > s.id;
      
      ctx.fillStyle = isDone ? "rgba(16, 185, 129, 0.2)" : (isCurrent ? "rgba(2, 132, 199, 0.25)" : "rgba(30, 41, 59, 0.4)");
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.strokeStyle = isDone ? "#10b981" : (isCurrent ? "#38bdf8" : "#334155");
      ctx.lineWidth = isCurrent ? 3 : 1.5;
      ctx.strokeRect(s.x, s.y, s.w, s.h);
      
      ctx.fillStyle = isDone ? "#10b981" : (isCurrent ? "#38bdf8" : "#64748b");
      ctx.font = "bold 11px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(s.name, s.x + s.w / 2, s.y + 20);
      
      // Ícones/Elementos Dentro de Cada Caixa
      if (s.id === 1) {
        // Botão de Emergência
        ctx.fillStyle = isDone ? "#991b1b" : "#ef4444";
        ctx.beginPath();
        ctx.arc(s.x + s.w / 2, s.y + 65, 24, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#fef2f2";
        ctx.font = "bold 10px Inter, sans-serif";
        ctx.fillText(isDone ? "PRESSIONADO" : "CLIQUE!", s.x + s.w / 2, s.y + 105);
      } else if (s.id === 2) {
        // Disjuntor
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(s.x + 30, s.y + 35, 30, 55);
        ctx.fillStyle = isDone ? "#10b981" : "#ef4444";
        ctx.fillRect(s.x + 35, isDone ? s.y + 60 : s.y + 40, 20, 25);
        ctx.fillStyle = "#94a3b8";
        ctx.fillText(isDone ? "OFF (0V)" : "ON (380V)", s.x + s.w / 2, s.y + 105);
      } else if (s.id === 3) {
        // Multímetro
        ctx.fillStyle = "#0284c7";
        ctx.fillRect(s.x + 20, s.y + 35, 50, 55);
        ctx.fillStyle = "#090d16";
        ctx.fillRect(s.x + 26, s.y + 42, 38, 20);
        ctx.fillStyle = "#4ade80";
        ctx.font = "bold 10px monospace";
        ctx.fillText(isDone ? "0.0 V" : "380 V", s.x + 45, s.y + 56);
        ctx.fillStyle = "#94a3b8";
        ctx.fillText(isDone ? "TESTADO" : "TESTAR", s.x + s.w / 2, s.y + 105);
      } else if (s.id === 4) {
        // Cadeado LOTO
        ctx.fillStyle = isDone ? "#10b981" : "#eab308";
        ctx.fillRect(s.x + 25, s.y + 50, 40, 35);
        ctx.strokeStyle = "#cbd5e1";
        ctx.lineWidth = 4;
        ctx.strokeRect(s.x + 33, s.y + 35, 24, 18);
        ctx.fillStyle = "#94a3b8";
        ctx.fillText(isDone ? "TRANCADO" : "TRAVAR", s.x + s.w / 2, s.y + 105);
      } else if (s.id === 5) {
        // Etiqueta LOTO
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(s.x + 25, s.y + 35, 40, 55);
        ctx.fillStyle = "#ef4444";
        ctx.fillRect(s.x + 25, s.y + 35, 40, 12);
        ctx.fillStyle = "#000000";
        ctx.font = "bold 7px Inter, sans-serif";
        ctx.fillText("PERIGO", s.x + 45, s.y + 44);
        ctx.fillStyle = "#94a3b8";
        ctx.font = "bold 11px Inter, sans-serif";
        ctx.fillText(isDone ? "IDENTIFICADO" : "ETIQUETAR", s.x + s.w / 2, s.y + 105);
      }
    });
    
    // Mensagem de Status Inferior
    ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
    ctx.fillRect(22, 270, 716, 65);
    ctx.strokeStyle = this.lotoState.step === 6 ? "#10b981" : "#0284c7";
    ctx.lineWidth = 2;
    ctx.strokeRect(22, 270, 716, 65);
    
    ctx.fillStyle = this.lotoState.step === 6 ? "#4ade80" : "#f8fafc";
    ctx.font = "bold 15px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(this.lotoState.message, this.canvas.width / 2, 308);
  }
  
  loop(timestamp) {
    const dt = timestamp - this.lastTime || 16;
    this.lastTime = timestamp;
    
    if (this.currentMode === "conveyor") {
      this.updateConveyor(dt);
      this.renderConveyor();
    } else {
      this.renderLoto();
    }
    
    requestAnimationFrame(this.loop);
  }
}
