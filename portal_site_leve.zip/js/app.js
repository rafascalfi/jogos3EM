// Controlador Principal da Aplicação do Portal de Jogos
document.addEventListener("DOMContentLoaded", () => {
  const gamesGrid = document.getElementById("gamesGrid");
  const searchInput = document.getElementById("searchInput");
  const filterButtons = document.querySelectorAll(".filter-btn");
  const modalOverlay = document.getElementById("gameModalOverlay");
  const modalCloseBtn = document.getElementById("modalCloseBtn");
  const toastNotice = document.getElementById("toastNotice");
  const toastText = document.getElementById("toastText");
  
  let currentCategory = "all";
  let searchQuery = "";
  
  // Inicializa Simulador Arcade
  const arcade = new ArcadeSimulator("arcadeCanvas");
  
  // Abas do Arcade
  const arcadeTabButtons = document.querySelectorAll(".arcade-tab-btn");
  arcadeTabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      arcadeTabButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const mode = btn.getAttribute("data-arcade-mode");
      arcade.switchMode(mode);
    });
  });
  
  // Renderizar Cards dos Jogos
  function renderGames() {
    gamesGrid.innerHTML = "";
    
    const filteredGames = GAMES_DATA.filter(game => {
      const matchesCategory = currentCategory === "all" || game.category === currentCategory;
      const matchesSearch = searchQuery === "" || 
        game.title.toLowerCase().includes(searchQuery) ||
        game.shortDesc.toLowerCase().includes(searchQuery) ||
        game.tags.some(tag => tag.toLowerCase().includes(searchQuery));
      return matchesCategory && matchesSearch;
    });
    
    if (filteredGames.length === 0) {
      gamesGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--text-dim);">
          <p style="font-size: 1.2rem; margin-bottom: 8px;">Nenhum projeto encontrado com estes termos.</p>
          <p style="font-size: 0.9rem;">Tente buscar por palavras como 'Segurança', 'Automação', 'CNC', 'Tycoon' ou limpe a busca.</p>
        </div>
      `;
      return;
    }
    
    filteredGames.forEach(game => {
      const card = document.createElement("div");
      card.className = "game-card";
      
      const isUnity = game.engine === "Unity";
      const engineClass = isUnity ? "badge-unity" : "badge-gamemaker";
      
      card.innerHTML = `
        <div class="card-thumb-wrapper">
          <img src="${game.thumbnail}" alt="${game.title}" class="card-thumb-img" onerror="this.src='assets/agrolock_cenario.png'">
          <span class="engine-badge ${engineClass}">${game.engineBadge}</span>
        </div>
        <div class="card-body">
          <div class="card-category-tag">${game.categoryLabel}</div>
          <h3 class="card-title">${game.title}</h3>
          <p class="card-description">${game.shortDesc}</p>
          
          <div class="card-tags">
            ${game.tags.slice(0, 3).map(tag => `<span class="tag-pill">#${tag}</span>`).join("")}
            <span class="tag-pill" style="color: var(--primary-light); font-weight: 600;">${game.size}</span>
          </div>
          
          <div class="card-footer">
            <button class="btn-card-detail" data-game-id="${game.id}">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
              Detalhes
            </button>
            <a href="${game.downloadPath}" download class="btn-card-download" data-title="${game.title}">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
              Baixar
            </a>
          </div>
        </div>
      `;
      
      // Clique no card ou no botão de detalhes abre o modal
      card.querySelector(".btn-card-detail").addEventListener("click", () => openModal(game));
      card.querySelector(".card-thumb-wrapper").addEventListener("click", () => openModal(game));
      card.querySelector(".card-thumb-wrapper").style.cursor = "pointer";
      
      // Notificação de download
      card.querySelector(".btn-card-download").addEventListener("click", (e) => {
        showToast(`Iniciando download do ${game.title} (${game.fileType})...`);
      });
      
      gamesGrid.appendChild(card);
    });
  }
  
  // Abrir Modal de Detalhes
  function openModal(game) {
    document.getElementById("modalBannerImg").src = game.banner || game.thumbnail;
    document.getElementById("modalTitle").textContent = game.title;
    document.getElementById("modalCategoryBadge").textContent = game.categoryLabel;
    document.getElementById("modalEngineBadge").textContent = game.engineBadge;
    document.getElementById("modalFileSize").textContent = `${game.fileType} • ${game.size}`;
    document.getElementById("modalFullDesc").textContent = game.fullDesc;
    
    // Objetivos
    const objectivesList = document.getElementById("modalObjectivesList");
    objectivesList.innerHTML = game.objectives.map(obj => `<li>${obj}</li>`).join("");
    
    // Controles
    const controlsTableBody = document.getElementById("modalControlsBody");
    controlsTableBody.innerHTML = game.controls.map(c => `
      <tr>
        <td style="width: 35%;"><kbd>${c.key}</kbd></td>
        <td>${c.action}</td>
      </tr>
    `).join("");
    
    // Como executar
    document.getElementById("modalHowToRun").textContent = game.howToRun;
    
    // Botão de download do modal
    const modalDownloadBtn = document.getElementById("modalDownloadBtn");
    modalDownloadBtn.href = game.downloadPath;
    modalDownloadBtn.onclick = () => showToast(`Iniciando download do ${game.title}...`);
    
    modalOverlay.classList.add("active");
    document.body.style.overflow = "hidden";
  }
  
  // Fechar Modal
  function closeModal() {
    modalOverlay.classList.remove("active");
    document.body.style.overflow = "";
  }
  
  modalCloseBtn.addEventListener("click", closeModal);
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) closeModal();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modalOverlay.classList.contains("active")) {
      closeModal();
    }
  });
  
  // Filtros de Categoria
  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentCategory = btn.getAttribute("data-filter");
      renderGames();
    });
  });
  
  // Busca em Tempo Real
  searchInput.addEventListener("input", (e) => {
    searchQuery = e.target.value.trim().toLowerCase();
    renderGames();
  });
  
  // Notificação Toast
  function showToast(message) {
    toastText.textContent = message;
    toastNotice.classList.add("show");
    setTimeout(() => {
      toastNotice.classList.remove("show");
    }, 4000);
  }
  
  // Render inicial
  renderGames();
});
